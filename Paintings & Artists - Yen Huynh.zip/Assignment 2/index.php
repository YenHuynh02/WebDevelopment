<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>Assign2-Home Page of Art Gallery</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/text.css" />
	<link rel="stylesheet" href="css/960.css" />

	<link rel="stylesheet" href="css/assign2.css" />
</head>

<body>

	<div class="container_12">
		<?php require_once("utilities/header.php"); ?>
		<div class="grid_3">
			<?php require_once("utilities/navigation.php"); ?>
		</div>
		<div class="grid_9">
			<?php
			$painting = file("resources/paintings.txt") or die("Error: Cannot find file");
			$artists = file("resources/artists.txt") or die("Error: Cannot find file");

			// Our data is tilde-delimited
			$demiliter = "~";

			// Check if genre selected
			if (isset($_GET['genre'])) {
				$choiceOfGen = $_GET['genre'];
			}

			// Display paintings
			foreach ($painting as $paint) {
				$paintingArr = explode($demiliter, $paint);
				$paintId = $paintingArr[0];
				$artName = $paintingArr[1];
				$title = $paintingArr[2];
				$genres = $paintingArr[9];

				// Check if the painting matches the genre
				// Decode the genre
				if (isset($_GET['genre']) && urldecode($_GET['genre']) !== $genres) {
					continue;
				}
				

				echo "<div>";
				echo "<img src='resources/paintings/square-small/" . $paintId . ".jpg' />";
				echo '<a style="position: absolute; left: 12em;" href="singlePainting.php?id=' . $paintId . '">' . $title . '</a>';

				foreach ($artists as $art) {

					$artistArr = explode($demiliter, $art);
					$artId = $artistArr[0];
					$artistName = $artistArr[1];

					if ($artistName == $artName) {
						echo '<a style="position: absolute; left: 41em;" href="singleArtist.php?id=' . $artId . '">' . $artistName . '</a>';
						break;
					}
				}

				echo "</div>";
			}
			?>
		</div>
		<div class="clear"> </div>
	</div>
</body>

</html>