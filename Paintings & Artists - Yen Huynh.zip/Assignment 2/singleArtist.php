<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>Assign2 - Single Artist</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/text.css" />
	<link rel="stylesheet" href="css/960.css" />

	<link rel="stylesheet" href="css/assign2.css" />
</head>

<body>

	<div class="container_12">
		<?php require_once("utilities/header.php"); ?>
		<div class="grid_3">
			<?php require_once("utilities/navigation.php"); ?>
		</div>
		<div class="grid_9">
			<?php
			if (isset($_GET['id'])) { // Check if the variable is set
				$artTistId = $_GET['id'];
				$artist = file("resources/artists.txt") or die("Error: Cannot find file");

				// Our data is tilde-delimited
				$demiliter = "~";

				foreach ($artist as $art) {
					$artistArr = explode($demiliter, $art);
					$currentArtId = $artistArr[0];

					if ($currentArtId == $artTistId) {
						$artistName = $artistArr[1];
						$national = $artistArr[2];
						$birth = $artistArr[3];
						$death = $artistArr[4];
						$descriptArt = $artistArr[5];
						$WikLink = $artistArr[6];
						break;
					}
				}


				if (isset($artistName)) {
					$painting = file("resources/paintings.txt") or die("Error: Cannot find file");
					echo "<img src='resources/artists/large/" . $currentArtId . ".jpg' />";
					echo "<h3>" . $artistName . "</h3>";
					echo $birth . " - " . $death . "<br>" . "(" . $national . ")<br><br>";
					echo $descriptArt . "<br><br>";
					echo "<a href='" . $WikLink . "' target=_blank; >" . $artistName . " on Wikipidea</a><br><br>";
					echo "<h3>Paintings</h3>";

					foreach ($painting as $paint) {
						$paintingArr = explode($demiliter, $paint);
						$paintId = $paintingArr[0];
						$artName = $paintingArr[1];
						$title = $paintingArr[2];

						if ($artName == $artistName) {
							echo "<ul><li>";
							echo '<a href="singlePainting.php?id=' . $paintId . '">' . $title . '</a>';
							echo "</li></ul>";
						}

					}
				}
			}
			?>
		</div>
		<div class="clear"> </div>
	</div>
</body>

</html>