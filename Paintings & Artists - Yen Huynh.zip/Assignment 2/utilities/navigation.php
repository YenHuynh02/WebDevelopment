<div id="genreListing">
	<h2>Genres</h2>	
	<ul class="secondaryList">
	<?php
		$painting = file("resources/paintings.txt") or die("Error: Cannot find file");
		$demiliter = "~";
		$genresArr = array();

		foreach ($painting as $index => $paint) {
			$paintingArr = explode($demiliter, $paint);
			$genres = $paintingArr[9];
			if(!in_array($genres, $genresArr)) { // Check if it already exists
				echo '<li><a href="index.php?genre='.urlencode($genres).'">'.$genres."</a></li>"; // Encode the genre
				$genresArr[] = $genres; // Add only 1 genres
			}

			if ($index === 24) { // Count the line to take the value of index
				break;
			}
		}
	?>
	</ul>
</div>

<div id="artistListing">
	<h2>Artists</h2>
	<ul class="secondaryList">
	<?php
	$artists = file("resources/artists.txt") or die("Error: Cannot find file");
	$demiliter = "~";
	$artirst = array();

	foreach ($artists as $art) {
		$artistsArr = explode($demiliter, $art);
		$artID = $artistsArr[0];
		$artName = $artistsArr[1];

		if(!in_array($artName, $artirst)) { // Check if it already exists
			echo '<li><a href="singleArtist.php?id='.$artID.'">'.$artName."</a></li>";
			$artistsArr[] = $artID; // Add only 1 artist
		}
	}
	?>	
	</ul>
</div>	