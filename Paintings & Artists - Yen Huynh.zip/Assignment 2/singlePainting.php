<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>Assign2 - Single Painting</title>
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/text.css" />
	<link rel="stylesheet" href="css/960.css" />

	<link rel="stylesheet" href="css/assign2.css" />
</head>

<body>

	<div class="container_12">
		<?php require_once("utilities/header.php"); ?>
	</div>
	<div class="container_12 contentWhite">
		<div class="grid_3">
			<?php require_once("utilities/navigation.php"); ?>
		</div>
		<div class="grid_9">
			<?php
			if (isset($_GET['id'])) { // Check if the variable is set
				$paintId = $_GET['id'];
				$painting = file("resources/paintings.txt") or die("Error: Cannot find file");

				// Our data is tilde-delimited
				$demiliter = "~";

				foreach ($painting as $paint) {
					$paintingArr = explode($demiliter, $paint);
					$currentPaintId = $paintingArr[0];

					if ($currentPaintId == $paintId) {
						$artNameP = $paintingArr[1];
						$titleP = $paintingArr[2];
						$yearP = $paintingArr[3];
						$widthP = $paintingArr[4];
						$heightP = $paintingArr[5];
						$priceP = $paintingArr[6];
						$descriptP = $paintingArr[7];
						$wikLinkP = $paintingArr[8];
						$genreN = $paintingArr[9];
						break;
					}
				}
			}

			if (isset($titleP)) {
				echo "<img src='resources/paintings/large/".$paintId.".jpg' />";
				echo "<h3>".$titleP."</h3><br>";
				echo "<b>";
				echo $artNameP."<br><br>";
				echo "(".$yearP." - ".$widthP."cm X ".$heightP."cm )<br><br>";
				echo $genreN."<br><br>";
				echo $descriptP."<br><br>";
				echo "<a href='".$wikLinkP."' target=_blank; >".$artNameP."on Wikipidea</a>";
				echo "</b>";
			}
			?>

		</div>
	</div>
	</div>
</body>

</html>