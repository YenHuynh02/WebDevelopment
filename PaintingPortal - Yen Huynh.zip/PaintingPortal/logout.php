<?php
session_start();
include("includes/config.php");

// Unset session variables
$_SESSION['login'] = false;
$_SESSION['username'] = '';

date_default_timezone_set('America/New_York');

// Redirect to index.php
header("Location: index.php");
exit();
?>
