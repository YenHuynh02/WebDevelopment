<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Handle the "Proceed to Checkout" button
if (isset($_POST['ordersubmit'])) {
	// Check if the user is logged in
	if (isset($_SESSION['login']) && $_SESSION['login']) {
		// User is logged in, redirect to payment-method.php
		header("Location: payment-method.php");
		exit();
	} else {
		// User is not logged in, redirect to login.php
		header("Location: login.php");
		exit();
	}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Meta -->
	<meta charset="utf-8">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="keywords" content="MediaCenter, Template, eCommerce">
	<meta name="robots" content="all">

	<title>My Cart</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/main.css">
	<link rel="stylesheet" href="assets/css/green.css">
	<link rel="stylesheet" href="assets/css/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/owl.transitions.css">
	<!--<link rel="stylesheet" href="assets/css/owl.theme.css">-->
	<link href="assets/css/lightbox.css" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/animate.min.css">
	<link rel="stylesheet" href="assets/css/rateit.css">
	<link rel="stylesheet" href="assets/css/bootstrap-select.min.css">

	<!-- Demo Purpose Only. Should be removed in production -->
	<link rel="stylesheet" href="assets/css/config.css">

	<link href="assets/css/green.css" rel="alternate stylesheet" title="Green color">
	<link href="assets/css/blue.css" rel="alternate stylesheet" title="Blue color">
	<link href="assets/css/red.css" rel="alternate stylesheet" title="Red color">
	<link href="assets/css/orange.css" rel="alternate stylesheet" title="Orange color">
	<link href="assets/css/dark-green.css" rel="alternate stylesheet" title="Darkgreen color">
	<!-- Demo Purpose Only. Should be removed in production : END -->


	<!-- Icons/Glyphs -->
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">

	<!-- Fonts -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css'>

	<!-- Favicon -->
	<link rel="shortcut icon" href="assets/images/favicon.ico">

	<!-- HTML5 elements and media queries Support for IE8 : HTML5 shim and Respond.js -->
	<!--[if lt IE 9]>
			<script src="assets/js/html5shiv.js"></script>
			<script src="assets/js/respond.min.js"></script>
		<![endif]-->

	<script>
		$(document).ready(function () {
			$('.quantity-input').on('input', function () {
				var pricePerUnit = <?php echo $paintingPrice; ?>;
				var newQuantity = parseInt($(this).val());

				if (isNaN(newQuantity) || newQuantity <= 0) {
					newQuantity = 1;
					$(this).val(newQuantity);
				}

				var newPrice = newQuantity > 1 ? pricePerUnit * newQuantity : pricePerUnit;


				var row = $(this).closest('tr');
				row.find('.cart-product-sub-total-price').html('$' + newPrice.toFixed(2));

				// Update the grand total if needed
				updateGrandTotal();
			});

			function updateGrandTotal() {
				var grandTotal = 0;
				$('.cart-product-sub-total-price').each(function () {
					grandTotal += parseFloat($(this).text().replace('$', ''));
				});
				$('.cart-grand-total span').text('$' + grandTotal.toFixed(2));
			}

			// Call the updateGrandTotal function initially
			updateGrandTotal();
		});
	</script>



</head>

<body class="cnt-home">



	<!-- ============================================== HEADER ============================================== -->
	<header class="header-style-1">
		<?php include('includes/top-header.php'); ?>
		<?php include('includes/main-header.php'); ?>
		<?php include('includes/menu-bar.php'); ?>
	</header>
	<!-- ============================================== HEADER : END ============================================== -->
	<div class="breadcrumb">
		<div class="container">
			<div class="breadcrumb-inner">
				<ul class="list-inline list-unstyled">
					<li><a href="index.php">Home</a></li>
					<li><a href="genre.php?id=1">Genres</a></li>
					<li class='active'>Cart</li>
					<li><a href="order-history.php">History</a></li>
				</ul>
			</div><!-- /.breadcrumb-inner -->
		</div><!-- /.container -->
	</div><!-- /.breadcrumb -->

	<div class="body-content outer-top-xs">
		<div class="container">
			<div class="row inner-bottom-sm">
				<div class="shopping-cart">
					<div class="col-md-12 col-sm-12 shopping-cart-table ">
						<div class="table-responsive">
							<form name="cart" method="post">
								<?php

								?>
								<table class="table table-bordered">
									<thead>
										<tr>
											<th class="cart-romove item">Remove</th>
											<th class="cart-description item">Image</th>
											<th class="cart-product-name item">Painting Title</th>

											<th class="cart-qty item">Quantity</th>
											<th class="cart-sub-total item">Price Per unit</th>
											<th class="cart-sub-total item">Shipping Charge</th>
											<th class="cart-total last-item">Grand Total</th>
										</tr>
									</thead><!-- /thead -->
									<tfoot>
										<tr>
											<td colspan="7">
												<div class="shopping-cart-btn">
													<span class="">
														<a href="index.php"
															class="btn btn-upper btn-primary outer-left-xs">Continue
															Shopping</a>
														<input type="submit" name="submit" value="Update shopping cart"
															class="btn btn-upper btn-primary pull-right outer-right-xs">
													</span>
												</div><!-- /.shopping-cart-btn -->
											</td>
										</tr>
									</tfoot>
									<tbody>
										<?php
										if ($_SERVER['REQUEST_METHOD'] === 'POST') {
											if (isset($_POST['addToCart']) && $_POST['addToCart'] === 'clicked') {
												$paintingImg = $_POST['paintingImage'];
												$paintingTitle = $_POST['paintingTitle'];
												$paintingPrice = $_POST['paintingPrice'];
												$shippingCharge = $_POST['shippingCharge'];

												$cartItem = [
													'paintingImage' => $paintingImg,
													'paintingTitle' => $paintingTitle,
													'paintingPrice' => $paintingPrice,
													'shippingCharge' => $shippingCharge
												];

												// Initialize or update the cart session
												if (!isset($_SESSION['cart'])) {
													$_SESSION['cart'] = [];
												}
												array_unshift($_SESSION['cart'], $cartItem); // Add the item to the beginning of the array
											}

											if (isset($_POST['submit']) && $_POST['submit'] === 'Update shopping cart') {
												foreach ($_POST['quantity'] as $index => $newQuantity) {
													if (isset($_SESSION['cart'][$index])) {
														if ($newQuantity <= 0) {
															// Remove the item if the quantity is zero or negative
															unset($_SESSION['cart'][$index]);
														} else {
															$_SESSION['cart'][$index]['quantity'] = $newQuantity;
														}
													}
												}

												// Reset the array keys to maintain consistency
												$_SESSION['cart'] = array_values($_SESSION['cart']);
											}

											// Handle removal of items based on checkboxes
											if (isset($_POST['remove_code']) && is_array($_POST['remove_code'])) {
												foreach ($_POST['remove_code'] as $index) {
													if (isset($_SESSION['cart'][$index])) {
														unset($_SESSION['cart'][$index]);
													}
												}

												// Reset the array keys to maintain consistency
												$_SESSION['cart'] = array_values($_SESSION['cart']);
											}
										}

										// Display the cart items
										if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
											$rowIndex = 0; // Counter for identifying each row
											foreach ($_SESSION['cart'] as $item) {
												echo "<tr class='cart-row cart-row-$rowIndex'>";
												echo "<td class='romove-item'><input type='checkbox' name='remove_code[]' value='{$rowIndex}' /></td>";
												echo "<td class='cart-image'><img src='admin/paintingImages/{$item['paintingImage']}' alt='{$item['paintingTitle']}' width='114' height='146'></td>";
												echo "<td class='cart-product-name-info'><h4 class='cart-product-description'>{$item['paintingTitle']}</h4></td>";
												$_SESSION['image'] = $item['paintingImage'];
												$_SESSION['title'] = $item['paintingTitle'];
												$_SESSION['num'] = 1;

												// Display quantity input field
												echo "<td class='cart-product-quantity'>";
												echo "<div class='quant-input'>";
												echo "<div class='arrows'>";
												echo "<div class='arrow plus gradient'><span class='ir'><i class='icon fa fa-sort-asc'></i></span></div>";
												echo "<div class='arrow minus gradient'><span class='ir'><i class='icon fa fa-sort-desc'></i></span></div>";
												echo "</div>";
												echo "<input type='text' value='1' name='quantity[]' min='1' class='quantity-input'>";
												echo "</div>";
												echo "</td>";

												// Calculate and display item subtotal
												$subtotal = $item['paintingPrice'] + $item['shippingCharge'];
												$_SESSION['PriceUnit'] = $subtotal;

												$shipCharge = $item['shippingCharge'];
												$_SESSION['ShipCharge'] = $shipCharge;
												
												echo "<td class='cart-product-sub-total'><span class='cart-sub-total-price'>$" . number_format($subtotal, 2) . "</span></td>";

												// Display shipping charge
												echo "<td class='cart-product-sub-total'><span class='cart-sub-total-price'>$" . number_format($item['shippingCharge'], 2) . "</span></td>";

												// Calculate and display item grand total
												$grandTotal = $subtotal + $item['shippingCharge'];
												echo "<td class='cart-product-grand-total'><span class='cart-grand-total-price'>$" . number_format($grandTotal, 2) . "</span></td>";

												// Add the item total to the combined grand total
												$combinedGrandTotal += $grandTotal;

												echo "</tr>";
												$rowIndex++;
											}

										} else {
											echo "<tr><td colspan='8'>Your cart is empty.</td></tr>";
										}

										?>

									</tbody><!-- /tbody -->
								</table><!-- /table -->

						</div>
					</div><!-- /.shopping-cart-table -->
					<div class="col-md-4 col-sm-12 estimate-ship-tax">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th>
										<span class="estimate-title">Shipping Address</span>
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>
										<div class="form-group">
											<?php
											// Code for User login
											$host = "localhost";
											$username = "ukbq7uujwgqth";
											$password = "Chippdl0212!";
											$database = "db9fhbiowny9lq";

											// Create a connection
											$read = new mysqli($host, $username, $password, $database);

											// Check connection
											if ($read->connect_error) {
												die("Connection failed: " . $read->connect_error);
											}

											// Display shipping address if user is logged in
											if (isset($_SESSION['login']) && $_SESSION['login'] && isset($_SESSION['email'])) {
												$email = $_SESSION['email'];

												// Query to get the user's shipping address
												$select_query = "SELECT shippingAddress FROM users WHERE email = ?";
												$stmt = $read->prepare($select_query);
												$stmt->bind_param("s", $email);
												$stmt->execute();
												$result = $stmt->get_result();

												if ($result->num_rows > 0) {
													$row = $result->fetch_assoc();
													echo $row['shippingAddress'];
												} else {
													echo "Shipping address not found.";
												}

												$stmt->close();
											}

											else {
												echo "Please login.";
											}
											?>

										</div>

									</td>
								</tr>
							</tbody><!-- /tbody -->
						</table><!-- /table -->
					</div>

					<div class="col-md-4 col-sm-12 estimate-ship-tax">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th>
										<span class="estimate-title">Billing Address</span>
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>
										<div class="form-group">
										<?php
											// Code for User login
											$host = "localhost";
											$username = "ukbq7uujwgqth";
											$password = "Chippdl0212!";
											$database = "db9fhbiowny9lq";

											// Create a connection
											$read = new mysqli($host, $username, $password, $database);

											// Check connection
											if ($read->connect_error) {
												die("Connection failed: " . $read->connect_error);
											}

											// Display billing address if user is logged in
											if (isset($_SESSION['login']) && $_SESSION['login'] && isset($_SESSION['email'])) {
												$email = $_SESSION['email'];

												// Query to get the user's billing address
												$select_query = "SELECT billingAddress FROM users WHERE email = ?";
												$stmt = $read->prepare($select_query);
												$stmt->bind_param("s", $email);
												$stmt->execute();
												$result = $stmt->get_result();

												if ($result->num_rows > 0) {
													$row = $result->fetch_assoc();
													echo $row['billingAddress'];
												} else {
													echo "Billing address not found.";
												}

												$stmt->close();
											}

											else {
												echo "Please login.";
											}
											?>
											<?php
											?>

										</div>

									</td>
								</tr>
							</tbody><!-- /tbody -->
						</table><!-- /table -->
					</div>
					<div class="col-md-4 col-sm-12 cart-shopping-total">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th>
										<div class="cart-grand-total">
											Grand Total<span class="inner-left-md">
												<?php echo "$" . number_format($combinedGrandTotal, 2); ?>
											</span>
										</div>
									</th>
								</tr>
							</thead><!-- /thead -->
							<tbody>
								<tr>
									<td>
										<div class="cart-checkout-btn pull-right">
											<form action="payment-method.php" method="post">
												<input type="hidden" name="paintingImg"
													value="<?php echo $paintingImg; ?>">
												<input type="hidden" name="quantity" value="<?php echo $quantity; ?>">
												<input type="submit" name="ordersubmit" class="btn btn-primary"
													value="PROCCED TO CHEKOUT">
											</form>
										</div>
									</td>
								</tr>
							</tbody><!-- /tbody -->
						</table>
						<?php
						?>
					</div>
				</div>
			</div>
			</form>

		</div>
	</div>
	<?php include('includes/footer.php'); ?>

	<script src="assets/js/jquery-1.11.1.min.js"></script>

	<script src="assets/js/bootstrap.min.js"></script>

	<script src="assets/js/bootstrap-hover-dropdown.min.js"></script>
	<script src="assets/js/owl.carousel.min.js"></script>

	<script src="assets/js/echo.min.js"></script>
	<script src="assets/js/jquery.easing-1.3.min.js"></script>
	<script src="assets/js/bootstrap-slider.min.js"></script>
	<script src="assets/js/jquery.rateit.min.js"></script>
	<script type="text/javascript" src="assets/js/lightbox.min.js"></script>
	<script src="assets/js/bootstrap-select.min.js"></script>
	<script src="assets/js/wow.min.js"></script>
	<script src="assets/js/scripts.js"></script>


	<script src="switchstylesheet/switchstylesheet.js"></script>

	<script>
		$(document).ready(function () {
			$(".changecolor").switchstylesheet({ seperator: "color" });
			$('.show-theme-options').click(function () {
				$(this).parent().toggleClass('open');
				return false;
			});
		});

		$(window).bind("load", function () {
			$('.show-theme-options').delay(2000).trigger('click');
		});
	</script>

</body>

</html>