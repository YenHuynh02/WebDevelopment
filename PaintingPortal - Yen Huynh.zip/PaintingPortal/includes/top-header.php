<div class="top-bar animate-dropdown">
    <div class="container">
        <div class="header-top-inner">
            <div class="cnt-account">
                <ul class="list-unstyled">

                <?php 
                session_start();
                if(isset($_SESSION['login']) && $_SESSION['login']) { ?>
                    <li><a href="#"><i class="icon fa fa-user"></i>Welcome - <?php echo $_SESSION['username']; ?></a></li>
                    <li><a href="logout.php"><i class="icon fa fa-sign-out"></i>Logout</a></li>
                <?php } else { ?>
                    <li><a href="login.php"><i class="icon fa fa-sign-in"></i>Login</a></li>
                <?php } ?>    
                    
                </ul>
            </div><!-- /.cnt-account -->
            <div class="clearfix"></div>
        </div><!-- /.header-top-inner -->
    </div><!-- /.container -->
</div><!-- /.header-top -->
