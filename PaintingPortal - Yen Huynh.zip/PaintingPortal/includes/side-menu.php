<div class="side-menu animate-dropdown outer-bottom-xs">
    <div class="head"><i class="icon fa fa-align-justify fa-fw"></i> Genre</div>
    <nav class="yamm megamenu-horizontal" role="navigation">

        <ul class="nav">
            <li class="dropdown menu-item">
                <?php
                $host = "localhost";
                $username = "ukbq7uujwgqth";
                $password = "Chippdl0212!";
                $database = "db9fhbiowny9lq";

                // Create a connection
                $read = new mysqli($host, $username, $password, $database);

                // Check connection
                if ($read->connect_error) {
                    die("Connection failed: " . $read->connect_error);
                }

                // Fetch genre information from the database
                $sql = "SELECT * FROM genre";
                $result = $read->query($sql);
                $genres = array();
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $genres[] = $row;
                    }
                }

                $read->close();
                ?>
                
                <?php foreach ($genres as $genre): ?>
                    <li><a href="genre.php?id=<?php echo $genre['id']; ?>"><?php echo $genre['genreName']; ?></a></li>
                <?php endforeach; ?>
                
            </li>
        </ul>
    </nav>
</div>