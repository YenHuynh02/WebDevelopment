<div class="header-nav animate-dropdown">
    <div class="container">
        <div class="yamm navbar navbar-default" role="navigation">
            <div class="navbar-header">
                <button data-target="#mc-horizontal-menu-collapse" data-toggle="collapse"
                    class="navbar-toggle collapsed" type="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="nav-bg-class">
                <div class="navbar-collapse collapse" id="mc-horizontal-menu-collapse">
                    <div class="nav-outer">
                        <ul class="nav navbar-nav">
                            <li class="active dropdown yamm-fw">
                                <a href="index.php" data-hover="dropdown" class="dropdown-toggle">Home</a>

                            </li>
                            <?php
                            $host = "localhost";
                            $username = "ukbq7uujwgqth";
                            $password = "Chippdl0212!";
                            $database = "db9fhbiowny9lq";

                            // Create a connection
                            $read = new mysqli($host, $username, $password, $database);

                            // Check connection
                            if ($read->connect_error) {
                                die("Connection failed: " . $read->connect_error);
                            }

                            // Fetch genre information from the database
                            $sql = "SELECT * FROM genre";
                            $result = $read->query($sql);
                            $genres = array();
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $genres[] = $row;
                                }
                            }

                            $read->close();
                            ?>

                            <li class="dropdown yamm">
                                    <?php foreach ($genres as $genre): ?>
                                        <li><a href="genre.php?id=<?php echo $genre['id']; ?>"><?php echo $genre['genreName']; ?></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            </li>

                            </li>



                        </ul><!-- /.navbar-nav -->
                        <div class="clearfix"></div>
                    </div>
                </div>


            </div>
        </div>
    </div>
</div>